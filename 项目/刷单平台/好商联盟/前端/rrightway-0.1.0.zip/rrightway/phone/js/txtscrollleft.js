(function () {
    setTimeout(function () {
        var dw = $("#scroll").width();
        var cw = $("#scroll div").width();
        var cx = 0;
        if (cw > dw) {
            $(".scrolltxt").append($(".scrolltxt").html());
            setInterval(function () {
                $(".scrolltxt").css({
                    "left": "-" + cx + "px"
                })
                if (cx > (cw - dw) + dw)
                    cx = 0;
                cx++;

            }, 30);
        }
    }, 500)

}(window));  