(function() {
    var imglist_all = $("#slider img[rel]");//document.getElementById("slider").getElementsByTagName("img");
    console.log(imglist_all.length);
    //加载图片	
    function loadImg(curPic) {
        var url = curPic.getAttribute("src2");
        if (url) {
            curPic.setAttribute("src", url);
            curPic.removeAttribute("src2");
        }
    }
    //图片张数
    function render(index, total, slideNum) {
		document.getElementById("JslideCmtCount").href=imglist_all[index].src;
		//alert(imglist_all[index].src);
        slideNum.innerHTML = (index * 1 + 1) + "/" + total;
    }
    //异步加载
    function getJson(url, fn, callbackName) {
        if (url.indexOf("?") != -1) {
            var url = url + '&func=' + callbackName;
        } else {
            var url = url + '?func=' + callbackName;
        }
        window[callbackName] = fn;
        var head = document.getElementsByTagName("head")[0];
        var script = document.createElement("script");
        script.src = url;
        script.onload = script.onreadystatechange = function() {
            var f = script.readyState;
            if (f && f != "loaded" && f != "complete") return;
            script.onload = script.onreadystatechange = null;
            head.removeChild(script);
            delete window[callbackName];
        };
        head.appendChild(script);
    }
    //图片转换
    function converse(url) {
		return url;
    }
    //增加节点
    function appendDom(toUrl, parentDom) {
        var aEle = document.createElement("a");
        aEle.className = "pic";
        aEle.innerHTML = '<img src2="' + toUrl + '" src="/images/loading.gif" class="lazy-img">';
        parentDom.appendChild(aEle);
    }
    //删除向前加载属性标识
    function delUnloadFlag(obj) {
        if (obj.getAttribute("data-front")) {
            obj.removeAttribute("data-front");
        }
    }
    function scroFix(obj) {
        var slideElem = document.getElementById("Jslider"),
        slideWrap = document.getElementById("Jslider-wrap"),
        slideCon = document.querySelector(".swipe-con"),
        slideNum = document.getElementById("JslideNum"),
        slideBack = document.getElementById("JslideBack"),
        hqBtn = document.getElementById("JhqBtn"),
        wrap = document.getElementById("Jlazy_img"),
        htmlDom = document.querySelector("html"),
        bodyDom = document.querySelector("body"),
        startRank = parseInt(obj.getAttribute("index")),
        startIndex = startRank - 1,
        pageSize = 30,
        totalLen = 0,
        curImg = obj.getAttribute("src");
        historyTop = document.body.scrollTop,
        onorientationEvt = "onorientationchange" in window ? "orientationchange": "resize";
        slideElem.style.display = "block";
        wrap.style.display = "none";
        bodyDom.style.background = "#000";
        slideElem.style.height = bodyDom.style.height = htmlDom.style.height = "100%";
        if (hqBtn) {
            hqBtn.style.display = "none";
        }
        function slide() {
            window.fullPicSlide = swipe(slideWrap, {
                startSlide: startIndex,
                continuous: false,
                disableScroll: true,
                callback: function(index, elem) {
                    window.scrollTo(0, 0);
                    var sizes = window.fullPicSlide && fullPicSlide.getNumSlides();
                   
                    var img = document.querySelectorAll("#Jslider-wrap img"),
                    prevFlag = index - 5;
                    var totalLen=imglist_all.length;
                    render(index, totalLen, slideNum);
                    //预加载前后一张
                    var nextPic = img[index + 1],
                    prevPic = img[index - 1];
                    if (sizes && index <= sizes - 1) {
                        if (nextPic) {
                            loadImg(nextPic);
                        }
                        if (prevPic) {
                            loadImg(prevPic);
                        }
                    }
                }
            });
        }
        var imgDom, backwardsStart = startRank <= 30 ? 1 : startRank - 10,
        forwardStart = startRank > 30 ? (startRank - 30) : 1,
        forwardPageSize = pageSize;
        //点击从第N张开始
        function frontPicDom() {
            for (var i = 0; i < startRank; i++) {
                var aEle = document.createElement("a");
                aEle.className = "pic";
                aEle.innerHTML = '<img data-front="1" src="/images/loading.gif" class="lazy-img">';
                slideCon.appendChild(aEle);
            }
            imgDom = document.querySelectorAll("#Jslider-wrap img");
        }
        function loadPic() {
			var allImgs = imglist_all;
			for (var j = 0; j < allImgs.length; j++) {
				
				 var curPic = j,
				picUrl = allImgs[j].alt,
				picRank = allImgs[j].index,
				toUrl = converse(picUrl);
				if (picRank <= startRank) { //图片节点已经存在
					var imgElem = imgDom[picRank - 1];
					imgElem.setAttribute("src2", toUrl);
					delUnloadFlag(imgElem);
				} else { //图片节点不存在
					appendDom(toUrl, slideCon);
				}
			}
			slide();
			fullPicSlide.setup();
        }
        loadPic();        
        slideElem.addEventListener("touchmove",
        function(e) {			
            if (e.touches.length > 1) {
                e.preventDefault();
            }
        },
        false);
        function closeBigPic() {
            slideElem.style.display = "none";
            wrap.style.display = "";
            bodyDom.style.background = "";
            slideElem.style.height = bodyDom.style.height = htmlDom.style.height = "";
            if (hqBtn) {
                hqBtn.style.display = "block";
            }
            fullPicSlide.kill();
            slideCon.innerHTML = "";
            window.scrollTo(0, historyTop);
        }
        slideBack.addEventListener("click", closeBigPic, false);
        slideWrap.addEventListener("click", closeBigPic, false);
        window.addEventListener(onorientationEvt,
        function() {
            window.scrollTo(0, 0);
        },
        false);
    }
    var allImgs = imglist_all;
    for (var j = 0; j < allImgs.length; j++) {
        //allImgs[j].addEventListener("click",null);
        allImgs[j].addEventListener("click",
        function() {
            //点击统计
            var parentDom = this.parentNode.tagName.toLowerCase();
            if (parentDom != "a") {
                var img = new Image;
                img.src = "/images/blankbg.gif";
            }
            scroFix(this);
        });
    }
})();