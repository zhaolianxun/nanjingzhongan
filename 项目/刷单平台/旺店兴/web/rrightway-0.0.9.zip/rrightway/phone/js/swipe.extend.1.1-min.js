function Swipe(I, z) {
    var S = function() {};
    var k = function(U) {
        setTimeout(U || S, 0);
    };
    var j = {
        addEventListener: !!window.addEventListener,
        touch: ("ontouchstart" in window) || window.DocumentTouch && document instanceof DocumentTouch,
        transitions: (function(U) {
            var W = ["transitionProperty", "WebkitTransition", "MozTransition", "OTransition", "msTransition"];
            for (var V in W) {
                if (U.style[W[V]] !== undefined) {
                    return true;
                }
            }
            return false;
        })(document.createElement("swipe"))
    };
    if (!I) {
        return;
    }
    var r = I.children[0];
    var l, Q, O, w, C, e, M, n;
    z = z || {};
    var G = parseInt(z.startSlide, 10) || 0;
    var N = z.speed || 300;
    z.continuous = z.continuous !== undefined ? z.continuous: false;	
	
	
    var D = j.transitions && (z.transform !== undefined ? z.transform: true);
    var K = z.vertical;
    var h, b, E, o;
    if (K) {
        h = "height",
        b = "top",
        E = "y",
        o = "x";
    } else {
        h = "width",
        b = "left",
        E = "x",
        o = "y";
    }
    var u = z.nav;
    n = u && u.children;
    if (u) {
        u.__length__ = n.length;
    }
    function m() {
		 //�Զ����ӵ�ǰλ��
		var navarray="";
		for(var i=0;i<r .children.length;i++)
		{
			if(i==0)
				navarray+="<a href='javascript:;' class='on'></a>";	
			else
				navarray+="<a href='javascript:;'></a>";	
		}
		var navlist=document.createElement("div");	
		navlist.className="slide_nav";	
		navlist.innerHTML=navarray;
		I.appendChild(navlist);
		
        l = r.children;
        w = l.length;
        G = p(G);
        C = z.slidesNum || 1;
        if (K) {
            O = (I.getBoundingClientRect().height || I.offsetHeight) / C;
        } else {
            O = (I.getBoundingClientRect().width || I.offsetWidth) / C;
        }
        e = z.continuous ? 1 : z.moveSlides || 1;
        M = O * e;
        if (n) {
            if (u.__length__ == 0) {
                var V = "";
                P(l,
                function(Z, Y) {
                    V += "<span>" + (Z + 1) + "</span>";
                });
                u.innerHTML = V;
                n = u.children;
            }
            P(n,
            function(Y, Z) {
                Z.addEventListener("click",
                function() {
                    v();
                    a(Y, N);
                },
                false);
                if (Y >= 0 && Y < 0 + C) {
                    Z.className = "current";
                } else {
                    Z.className = "";
                }
            });
        }
        if (l.length < 2) {
            z.continuous = false;
        }
        if (j.transitions && z.continuous && l.length < 3) {
            r.appendChild(l[0].cloneNode(true));
            r.appendChild(r.children[1].cloneNode(true));
            l = r.children;
        }
        Q = new Array(l.length);
        r.style[h] = (l.length * O) + "px";
        r.style.position = "relative";
        var X = l.length;
        while (X--) {
            var W = l[X];
            W.style[h] = O + "px";
            W.style.cssFloat = "left";
            W.style.display = "inline";
            W.setAttribute("data-index", X);
            var U = (X * -O);
            if (j.transitions && z.continuous) {
                W.style[b] = U + "px";
                W.style.position = "relative";
                s(X, G > X ? -O: (G < X ? O: 0), 0);
            } else {
                Q[X] = U;
            }
        }
        if (z.continuous && j.transitions) {
            s(x(G - 1), -O, 0);
            s(x(G + 1), O, 0);
        }
        if (!z.continuous) {
            if (D) {
                g(r, Q[G], 0);
            } else {
                r.style[b] = Q[G] + "px";
            }
        }
        I.style.visibility = "visible";
        T(G, C, true);
        L(G, l[G]);
    }
    function P(V, X) {
        for (var W = 0,
        U = V.length; W < U; W++) {
            X.call(this, W, V[W]);
        }
    }
    function F() {
        if (z.continuous) {
            a(G - 1);
        } else {
            if (G) {
                a(G - 1);
            }
        }
    }
    function i() {
        if (z.continuous) {
            a(G + 1);
        } else {
            if (G < l.length - 1) {
                a(G + 1);
            }
        }
    }
    function x(U) {
        return (l.length + (U % l.length)) % l.length;
    }
    function p(U) {
        return (U > l.length - 1 - C) ? l.length - C: U;
    }
    function s(U, W, V) {
        g(l[U], W, V);
        Q[U] = W;
    }
    function g(U, W, V) {
        if (K) {
            g = function(X, aa, Z) {
                var Y = X && X.style;
                if (!Y) {
                    return;
                }
                Y.webkitTransitionDuration = Y.MozTransitionDuration = Y.msTransitionDuration = Y.OTransitionDuration = Y.transitionDuration = Z + "ms";
                Y.webkitTransform = "translate(0," + aa + "px)translateZ(0)";
                Y.msTransform = Y.MozTransform = Y.OTransform = "translateY(" + aa + "px)";
            };
        } else {
            g = function(X, aa, Z) {
                var Y = X && X.style;
                if (!Y) {
                    return;
                }
                Y.webkitTransitionDuration = Y.MozTransitionDuration = Y.msTransitionDuration = Y.OTransitionDuration = Y.transitionDuration = Z + "ms";
                Y.webkitTransform = "translate(" + aa + "px,0)translateZ(0)";
                Y.msTransform = Y.MozTransform = Y.OTransform = "translateX(" + aa + "px)";
            };
        }
    }
    function R(Y, X, U) {
        if (!U) {
            r.style[b] = X + "px";
            return;
        }
        var W = +new Date;
        var V = setInterval(function() {
            var Z = +new Date - W;
            if (Z > U) {
                r.style[b] = X + "px";
                if (H) {
                    q();
                }
                z.transitionEnd && z.transitionEnd.call(event, G, l[G]);
                clearInterval(V);
                return;
            }
            r.style[b] = (((X - Y) * (Math.floor((Z / U) * 100) / 100)) + Y) + "px";
        },
        4);
    }
    var H = z.auto || 0;
    var f;
    function q() {
        f = setTimeout(i, H);
    }
    function v() {
        H = 0;
        clearTimeout(f);
    }
    var B = {};
    var J = {};
    var d, c;
    function a(Y, V) {
        if (G == Y) {
            return;
        }
        if (j.transitions && z.continuous) {
            var X = Math.abs(G - Y) / (G - Y);
            var U = X;
            X = -Q[x(Y)] / O;
            if (X !== U) {
                Y = -X * l.length + Y;
            }
            var W = Math.abs(G - Y) - 1;
            while (W--) {
                s(x((Y > G ? Y: G) - W - 1), O * X, 0);
            }
            Y = x(Y);
            s(G, O * X, V || N);
            s(Y, 0, V || N);
            if (z.continuous) {
                s(x(Y - X), -(O * X), 0);
            }
        } else {
            Y = p(Y);
            if (D) {
                g(r, Q[Y], N);
            } else {
                R(Q[G], Q[Y], N);
            }
        }
        G = Y;
        t(Y);
        L(G);
    }
    function t(U) {
        T(U, C, false);
        z.transitionStart && z.transitionStart(U, l[U]);
    }
    function T(W, Y, V) {
        var X = z.imgSrc || "src2";
        var aa = W,
        U = W + Y + 1;
        if (V) {
            U = W + Y;
            window.addEventListener("load",
            function() {
                setTimeout(function() {
                    T(W, Y, false);
                },
                2000);
            },
            false);
        }
        for (; aa < U; aa++) {
            if (!l[aa]) {
                continue;
            }
            var Z = l[aa].querySelectorAll("img[" + X + "]");
            if (!Z) {
                continue;
            }
            P(Z,
            function(ac, ae) {
                var ad = ae.getAttribute("src2"),
                ab = new Image();
                ab.onload = function() {
                    ae.setAttribute("src", ad);
                    ae.removeAttribute("src2");
                };
                ab.src = ad;
            });
        }
    }
    function L(U) {
        var U = U % w;
        z.nav && y(U, C);
        z.callback && z.callback(U, l[U]);
    }
    function y(V, U) {
        P(n,
        function(W, X) {
            if (W >= V && W < V + U) {
                X.className = "current";
            } else {
                X.className = "";
            }
        });
    }
    var A = {
        handleEvent: function(U) {
            switch (U.type) {
            case "touchstart":
                this.start(U);
                break;
            case "touchmove":
                this.move(U);
                break;
            case "touchend":
                k(this.end(U));
                break;
            case "webkitTransitionEnd":
            case "msTransitionEnd":
            case "oTransitionEnd":
            case "otransitionend":
            case "transitionend":
                k(this.transitionEnd(U));
                break;
            case "resize":
                if (m.timer) {
                    clearTimeout(m.timer);
                }
                m.timer = setTimeout(m, 250);
                break;
            }
            if (z.stopPropagation) {
                U.stopPropagation();
            }
        },
        start: function(U) {
            var V = U.touches[0];
            B = {
                x: V.pageX,
                y: V.pageY,
                time: +new Date
            };
            d = undefined;
            c = false;
            J = {};
            r.addEventListener("touchmove", this, false);
            r.addEventListener("touchend", this, false);
        },
        move: function(V) {
            if (l[G].getAttribute("disableSlide")) {
                return;
            }
            if (V.touches.length > 1 || V.scale && V.scale !== 1) {
                return;
            }
            if (z.disableScroll) {
                V.preventDefault();
            }
            var X = V.touches[0];
            J = {
                x: X.pageX - B.x,
                y: X.pageY - B.y
            };
            if (typeof d == "undefined") {
                d = !!(d || Math.abs(J[E]) < Math.abs(J[o]));
            }
            if (!d) {
                V.preventDefault();
                v();
                var U, W;
                if (z.continuous) {
                    U = x(G - 1);
                    W = x(G + 1);
                    g(l[U], J[E] + Q[x(G - 1)], 0);
                    g(l[G], J[E] + Q[G], 0);
                    g(l[W], J[E] + Q[x(G + 1)], 0);
                } else {
                    J[E] = J[E] / ((!G && J[E] > 0 || G == l.length - C && J[E] < 0) ? (Math.abs(J[E]) / M + 1) : 1);
                    if (D) {
                        g(r, J[E] + Q[G], 0);
                    } else {
                        R(Q[G], J[E] + Q[G], 0);
                    }
                }
                if (!c) {
                    if (!z.continuous) {
                        U = ((G - e) <= 0) ? 0 : G - e;
                        W = p(G + e);
                    }
                    if (J[E] < 0) {
                        t(W);
                    }
                    if (J[E] > 0) {
                        t(U);
                    }
                    c = true;
                }
            }
        },
        end: function(X) {
            var aa = +new Date - B.time;
            var W = Number(aa) < 250 && Math.abs(J[E]) > 20 || Math.abs(J[E]) > M / 2;
            var Z = !G && J[E] > 0,
            V = (G == l.length - C && J[E] < 0);
            var U = z.continuous ? false: Z || V;
            var Y = J[E] < 0;
            if (!d) {
                if (W && !U) {
                    if (Y) {
                        if (z.continuous) {
                            s(x(G - 1), -O, 0);
                            s(x(G + 2), O, 0);
                            s(G, Q[G] - O, N);
                            s(x(G + 1), Q[x(G + 1)] - O, N);
                            G = x(G + 1);
                        } else {
                            var ab = p(G + e);
                            if (D) {
                                g(r, Q[ab], N);
                            } else {
                                R(J[E] + Q[G], Q[ab], N);
                            }
                            G = ab;
                        }
                    } else {
                        if (z.continuous) {
                            s(x(G + 1), O, 0);
                            s(x(G - 2), -O, 0);
                            s(G, Q[G] + O, N);
                            s(x(G - 1), Q[x(G - 1)] + O, N);
                            G = x(G - 1);
                        } else {
                            var ab = ((G - e) <= 0) ? 0 : G - e;
                            if (D) {
                                g(r, Q[ab], N);
                            } else {
                                R(J[E] + Q[G], Q[ab], N);
                            }
                            G = ab;
                        }
                    }
                    L(G);
                } else {
                    if (z.continuous) {
                        s(x(G - 1), -O, N);
                        s(G, 0, N);
                        s(x(G + 1), O, N);
                    } else {
                        if (D) {
                            g(r, Q[G], N);
                        } else {
                            R(J[E] + Q[G], Q[G], N);
                        }
                        if (Y) {
                            z.pastEnd && z.pastEnd(G, l[G]);
                        } else {
                            z.pastStart && z.pastStart(G, l[G]);
                        }
                    }
                }
            }
            r.removeEventListener("touchmove", A, false);
            r.removeEventListener("touchend", A, false);
        },
        transitionEnd: function(V) {
            var U;
            if (z.continuous) {
                if (parseInt(V.target.getAttribute("data-index"), 10) == G) {
                    U = true;
                }
            } else {
                U = true;
            }
            if (U) {
                if (H) {
                    q();
                }
                z.transitionEnd && z.transitionEnd.call(V, G, l[G]);
            }
        }
    };
    m();
    if (H) {
        q();
    }
    if (j.addEventListener) {
        if (j.touch) {
            r.addEventListener("touchstart", A, false);
        }
        if (D) {
            r.addEventListener("webkitTransitionEnd", A, false);
            r.addEventListener("msTransitionEnd", A, false);
            r.addEventListener("oTransitionEnd", A, false);
            r.addEventListener("otransitionend", A, false);
            r.addEventListener("transitionend", A, false);
        }
        window.addEventListener("resize", A, false);
    } else {
        window.onresize = function() {
            m();
        };
    }
    return {
        options: z,
        setup: function() {
            m();
        },
        slide: function(V, U) {
            v();
            a(V, U);
        },
        prev: function() {
            v();
            F();
        },
        next: function() {
            v();
            i();
        },
        stop: function() {
            v();
        },
        getPos: function() {
            return G;
        },
        getNumSlides: function() {
            return w;
        },
        kill: function() {
            v();
            r.style[h] = "";
            r.style[b] = "";
            var V = l.length;
            while (V--) {
                var U = l[V];
                U.style[h] = "";
                U.style[b] = "";
                if (D) {
                    g(l[V], 0, 0);
                }
            }
            if (j.addEventListener) {
                r.removeEventListener("touchstart", A, false);
                r.removeEventListener("webkitTransitionEnd", A, false);
                r.removeEventListener("msTransitionEnd", A, false);
                r.removeEventListener("oTransitionEnd", A, false);
                r.removeEventListener("otransitionend", A, false);
                r.removeEventListener("transitionend", A, false);
                window.removeEventListener("resize", A, false);
            } else {
                window.onresize = null;
            }
        }
    };
}
if (window.jQuery || window.Zepto) { (function(a) {
        a.fn.Swipe = function(b) {
            return this.each(function() {
                a(this).data("Swipe", new Swipe(a(this)[0], b));
            });
        };
    })(window.jQuery || window.Zepto);
}
function swipe(a, b) {
    return Swipe(a, b);
}