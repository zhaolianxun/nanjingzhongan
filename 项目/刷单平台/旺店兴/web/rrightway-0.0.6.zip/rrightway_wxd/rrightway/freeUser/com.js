/*右边固定导航*/
$(function(){
    //$("body").append('');
	var isopen=0;
	if(!$(".nav_menu .menu").hasClass("open")){		
		$(".nav_menu .menu").hover(function(){
			if(isopen==0){
				$(this).find("div").eq(0).slideDown(300);
				setTimeout(function(){
					isopen=1;
				},300);
			}
		},function(){
			if(isopen==1){
				$(this).find("div").eq(0).slideUp(300);
				setTimeout(function(){
					isopen=0;
				},300);
				
			}
		});
	}
	
	if($(".t_menu").length>0){		
		$(".t_menu a.change").hover(function(){
			if(!$(this).hasClass("crently"))
			{
				var al=$(this).position().left;
				var awidth=$(this).width();
				$(this).addClass("crently").siblings().removeClass("crently");
				$(this).parents(".t_menu").find(".t_hover").animate({"left":al+"px","width":awidth+"px"},200);
				$(this).parents(".tab_area").find(".tab_txt").hide();
				$(this).parents(".tab_area").find(".tab_txt").eq($(this).index()).show();
			}
		})		
		$(".t_menu").each(function(){
			$(this).find(".t_hover").css({"width":$(this).find("a.change").eq(0).width()});	
		});
	}
		
	if($(".clearinput").length>0){
        $(".clearinput").parent().append('<i class="ico_inputclose"></i>')
        $('.clearinput').keyup(function(){         
            //console.log($(this).val());
            if($(this).val().replace(/\s+/g,"")!=""){
                $(this).parent().find(".ico_inputclose").eq(0).show();
            }else{ 
                $(this).parent().find(".ico_inputclose").eq(0).hide();
            }
        });
        
        $('.clearinput').focus(function(){         
            //console.log($(this).val());
            if($(this).val().replace(/\s+/g,"")!=""){
                $(this).parent().find(".ico_inputclose").eq(0).show();
            }else{ 
                $(this).parent().find(".ico_inputclose").eq(0).hide();
            }
        });
        
        $(".ico_inputclose").click(function(){
            $(this).parent().find(".clearinput").eq(0).val("");
            $(this).parent().find(".clearinput").eq(0).focus();
            $(this).hide();
        })
    }

    var scrollstop = 1;
    $(window).scroll(function () {
        if (scrollstop != 0) {
            if ($(window).scrollTop() > 200) {
                $(".gotop").fadeIn();
				$(".side-bar dd").addClass("show");
            }
            else {
                $(".gotop").fadeOut();
				$(".side-bar dd").removeClass("show");
            }
            if ($(window).scrollTop() == 0) {
                scrollstop = 1;
            }
			if($(window).scrollTop() > 280)
				$(".header.fixed").addClass("show");
			else
				$(".header.fixed").removeClass("show");
        }
    });

    $(".gotop").click(function () {
        scrollstop = 0;
        $(".gotop").fadeOut();
		$(".side-bar dd").removeClass("show");
        $('html,body').animate({ 'scrollTop': 0 }, 300);
        setTimeout(function () { scrollstop = 1 }, 300);
    });
		
	
	//返利导购菜单
	$(".top_bar span").hover(function(){
		if($(this).find("p").length>0)
		{
			$(this).find("p").eq(0).slideDown(100);
			$(this).addClass("crently").siblings().removeClass("crently");
			
		}
	},function(){
		if($(this).find("p").length>0)
		{
			$(this).find("p").eq(0).slideUp(100);
			$(this).removeClass("crently");
		}
	});	
});


function getArgs(name) {
    var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)");
    var r = window.location.search.substr(1).match(reg);
    if (r != null) return unescape(r[2]); return null;
}


function isEmptyValue(value) {

    var type;
    if (value == null) { // 等同于 value === undefined || value === null
        return true;
    }
    type = Object.prototype.toString.call(value).slice(8, -1);
    switch (type) {
        case 'String':
            return !$.trim(value);
        case 'Array':
            return !value.length;
        case 'Object':
            return $.isEmptyObject(value); // 普通对象使用 for...in 判断，有 key 即为 false
        default:
            return false; // 其他对象均视作非空
    }
};


//刷新当前页
function freshpage(url) {
    setTimeout(function () {
        window.location.href = url;
    }, 2000);
}


