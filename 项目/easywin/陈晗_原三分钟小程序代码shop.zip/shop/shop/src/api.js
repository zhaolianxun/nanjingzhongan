import wepy from 'wepy'
import pathToRegexp from 'path-to-regexp'
import tip from './utils/tip'
import { USER_INFO } from './utils/constant'

const { apiUrl = '', platAppId } = wx.getExtConfigSync()

const apiMall = `${apiUrl || ''}/m`

exports.index = () => wxRequest(
  '/e/home'
)

exports.login = ({ code }) => wxRequest(
  '/useraction/login',
  { jscode: code },
  'POST'
)

exports.userInfo = (token, data) => wxRequest(
  pathForamt({ token }, '/userInfo?token=:token')
)

exports.updateUserInfo = (token, data) => wxRequest(
  pathForamt({ token }, '/updateUserInfo?token=:token'),
  data,
  'POST'
)

exports.category = (params = '') => wxRequest(
  '/e/goodtype'
)

exports.categoryChild = parentId => wxRequest(
  '/e/goodtype/type2s',
  { type1_id: parentId }
)

exports.verifyCode = data => wxRequest(
  '/e/i/bindphone',
  data,
  'POST'
)

exports.bindPhone = (token, data) => wxRequest(
  pathForamt({ token }, '/sms/bindPhone?token=:token'),
  data,
  'POST'
)

exports.addressList = (token) => wxRequest(
  pathForamt({ token }, '/address/list?token=:token')
)

exports.regions = (token) => wxRequest(
  '/region/all'
)

// 传id表示修改地址
exports.addressAct = (token, data) => wxRequest(
  pathForamt({ token }, '/address/addOrUpdate?token=:token'),
  data,
  'POST'
)

exports.delAddress = (token, id) => wxRequest(
  pathForamt({ token, id }, '/address/:id/delete?token=:token'),
  {},
  'POST'
)

exports.getGoodsDetail = goodsId => wxRequest(
  '/e/gooddetail',
  { good_id: goodsId }
)

exports.isFavorite = (goodsId, token) => wxRequest(
  pathForamt({ goodsId, token }, '/product/:goodsId/followState?token=:token')
)

exports.setFavorite = (goodsId, token) => wxRequest(
  pathForamt({ goodsId, token }, '/product/:goodsId/followUpdate?token=:token'),
  {},
  'POST'
)

exports.favoriteList = (token, page) => wxRequest(
  pathForamt({ token, page }, '/product/followed?token=:token&page=:page')
)

exports.search = (data) => wxRequest( // key_word order_by rder_orientation 排序方式: 取值: default 综合,sold_count 销量,price 价格 排序方向: asc 升序 ,desc 降序
  '/e/homesearch/search',
  data
)

exports.cateGoodsList = data => wxRequest(
  '/e/goodtype/type2s',
  data
)

exports.cartList = (token) => wxRequest(
  pathForamt({ token }, '/e/cart?token=:token')
)

exports.addCart = (goodsId, token, sku_id, quantity) => wxRequest(
  pathForamt({ goodsId, token }, '/product/:goodsId/addCart?token=:token'),
  {
    sku_id,
    quantity
  },
  'POST'
)

exports.numCart = data => wxRequest(
  '/e/cart/changecount',
  data,
  'POST'
)

exports.delCart = data => wxRequest(
  '/e/cart/remove',
  data,
  'POST'
)

exports.userDefaultAddress = (token) => wxRequest(
  pathForamt({ token }, '/address/default?token=:token')
)

exports.setOrderOne = (goodsId, token, data) => wxRequest(
  pathForamt({ token, goodsId }, '/product/:goodsId/orderCreate?token=:token'),
  data,
  'POST'
)

exports.setOrder = (token, data) => wxRequest(
  pathForamt({ token }, '/cart/orderCreate?token=:token'),
  data,
  'POST'
)

exports.orderList = (token, data) => wxRequest(
  pathForamt({ token }, '/order?token=:token'),
  data
)

exports.cancelOrder = (token, id) => wxRequest(
  pathForamt({ token, id }, '/order/cancel?token=:token&order_ids[]=:id'),
  {},
  'POST'
)

exports.delOrder = (token, id) => wxRequest(
  pathForamt({ token, id }, '/order/delete?token=:token&order_ids[]=:id'),
  {},
  'POST'
)

exports.confirmOrder = (data) => wxRequest(
  '/order/confirmReceived',
  data,
  'POST'
)

exports.orderDetail = (token, id) => wxRequest(
  pathForamt({ token, id }, '/order/:id??token=:token')
)

exports.getWxPaySign = (token, no) => wxRequest(
  pathForamt({ token, no }, '/order/:no/paySign?token=:token')
)

exports.salesInfo = (token) => wxRequest(
  pathForamt({ token }, '/rebate/profile?token=:token')
)

exports.bankList = () => wxRequest('/bank')

exports.updateBankInfo = (token, data) => wxRequest(
  pathForamt({ token }, '/updateBankInfo?token=:token'),
  data,
  'POST'
)

exports.withdraw = (token) => wxRequest(
  pathForamt({ token }, '/rebate/withdraw?token=:token'),
  {},
  'POST'
)

exports.fansList = (token, page) => wxRequest(
  pathForamt({ token, page }, '/rebate/subMembers?token=:token&page=:page')
)

exports.incomeList = (token, page) => wxRequest(
  pathForamt({ token, page }, '/rebate/incomeList?token=:token&page=:page')
)

exports.withdrawList = (token, page) => wxRequest(
  pathForamt({ token, page }, '/rebate/withdrawList?token=:token&page=:page')
)

exports.qrcode = (token) => wxRequest(
  pathForamt({ token }, '/promotionQrcode?token=:token')
)

exports.config = () => wxRequest(
  '/config'
)

exports.couponList = (token, page, state) => wxRequest(
  pathForamt({ token, page, state }, '/coupon/fetchedList?token=:token&page=:page&state=:state')
)

exports.mallCoupon = () => wxRequest(
  '/coupon'
)

exports.getCoupon = (token, id) => wxRequest(
  pathForamt({ token, id }, '/coupon/:id/fetch?token=:token')
)

exports.getCouponByCart = (token, cart_ids) => wxRequest(
  pathForamt({ token, cart_ids }, '/cart/availableUserCoupons?token=:token&cart_ids=:cart_ids'),
)

exports.getCouponByGoods = (token, goodsId, quantity) => wxRequest(
  pathForamt({ token, goodsId, quantity }, '/product/:goodsId/availableUserCoupons?token=:token&quantity=:quantity')
)

function pathForamt (params, url) {
  return pathToRegexp.compile(url)(params)
}

const wxRequest = (url, data = {}, method = 'GET', header = {}) => new Promise((resolve, reject) => {
  if (!apiUrl) {
    reject()
  }

  wepy.showLoading({
    title: '加载中...',
    mask: true
  })

  data.mall_id = platAppId

  wepy.request({
    url: apiMall + url,
    method: method,
    data,
    // header
    header: { 'Content-Type': 'application/x-www-form-urlencoded' }
  }).then(({ data, statusCode }) => {
    wx.hideLoading()

    if (statusCode === 401) {
      wepy.removeStorage({
        key: USER_INFO
      })

      tip.error('获取用户信息失败，请重新进入小程序')
    } else {
      resolve(data)
    }
  }).catch(err => {
    wx.hideLoading()
    reject(err)
  })
})
