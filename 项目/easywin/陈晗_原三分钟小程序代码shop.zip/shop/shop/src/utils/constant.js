/**
 * 用户信息
 * @type {String}
 */
export const USER_INFO = 'userInfo'

export const SEL_ADDRESS = 'selAddress'

export const SYSTEM_INFO = 'systemInfo'

export const SEL_CLASS_CODE = 'selClassCode'

export const EXPIRES_TIME = 604800000 // 7天有效期

export const PROVINCE_LIST = 'provinceList'

export const USER_BROWSER = 'userBrowser'

export const SEARCH_HISTORY = 'searchHistory'

export const CONFIRM_ORDER_INFO = 'confirmOrderInfo'

export const ACCOUNT_INFO = 'accountInfo'

export const BANK_LIST = 'bankList'

export const SEL_COUPON = 'selCoupon'
