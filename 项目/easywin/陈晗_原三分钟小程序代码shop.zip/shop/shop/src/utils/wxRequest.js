import wepy from 'wepy'

const wxRequest = async({ data = {}, method = 'GET' }, url) => {
    wepy.showToast({
        title: '加载中',
        icon: 'loading'
    })

    let res = await wepy.request({
        url: url,
        method: method,
        data: data,
        header: { 'Content-Type': 'application/x-www-form-urlencoded' },
    })

    wepy.hideToast()
    return res
};


module.exports = {
    wxRequest
}
